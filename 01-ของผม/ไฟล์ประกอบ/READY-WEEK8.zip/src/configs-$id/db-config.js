import mysql from 'mysql2/promise';
// เปลี่ยนชื่อฐานข้อมูลและรหัสผ่านให้ตรงเครื่อง
export default mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'mobile_distributor',
  decimalNumbers: true, dateStrings: true, connectionLimit: 5
});
